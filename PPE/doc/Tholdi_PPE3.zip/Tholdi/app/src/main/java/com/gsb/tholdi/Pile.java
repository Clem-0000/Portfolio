package com.gsb.tholdi;

import java.util.List;

public class Pile {
    private char numPile;
    private char numTravee;
    private char codeBloc;
    private int capacite;
    private List<Pile> lesPiles;
}
