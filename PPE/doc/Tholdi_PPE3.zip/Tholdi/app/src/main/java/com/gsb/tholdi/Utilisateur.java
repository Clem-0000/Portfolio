package com.gsb.tholdi;

public class Utilisateur {
    private int numUtilisateur;
    private String RaisonSociale;
    private String login;
    private String password;
    private String type;

}
