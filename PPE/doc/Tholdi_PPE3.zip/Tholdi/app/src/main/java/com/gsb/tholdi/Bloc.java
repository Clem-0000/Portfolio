package com.gsb.tholdi;

import java.util.List;

public class Bloc {
    private char codeBloc;
    private List<Travee> lesTravees;
}
