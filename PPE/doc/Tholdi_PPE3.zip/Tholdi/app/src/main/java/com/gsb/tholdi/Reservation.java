package com.gsb.tholdi;

import java.util.List;

public class Reservation {

}
