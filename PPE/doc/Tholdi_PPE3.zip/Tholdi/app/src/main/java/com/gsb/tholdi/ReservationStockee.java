package com.gsb.tholdi;

import java.util.List;

public class ReservationStockee {
    private List<Reservation> lesReservations;
    private List<Pile> lesPiles;
}
