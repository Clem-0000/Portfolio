﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsForm_Menu
{
    public partial class FormMenu : Form
    {

        private static MySqlConnection _connexion = new MySqlConnection("Database=tholdi_pp3;Data Source=localhost;User Id=root;Password=''");
        

        public FormMenu()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 log = new Form1();
            this.Close();
            log.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void index_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FormMenu_Load(object sender, EventArgs e)
        {
           // List<Declaration> declarations = null;
            //declarations = Declaration.FetchAll();
           //dataGridView1.DataSource = declarations;

            UseControle user = new UseControle();
            flowLayoutPanelPrincipale.Controls.Add(user);
        }

        private void button2_Click(object sender, EventArgs e)  
        {

           // UserControl2.dataGridView1.Show();

            flowLayoutPanelPrincipale.Controls.Clear();
            UserControl2 user = new UserControl2();
            flowLayoutPanelPrincipale.Controls.Add(user);
        }

        private void container_Click(object sender, EventArgs e)
        {
            //index.Show();
            //dataGridView1.Hide();

            flowLayoutPanelPrincipale.Controls.Clear();
            UseControle user = new UseControle();
            flowLayoutPanelPrincipale.Controls.Add(user);

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<Declaration> declarations = null;
            declarations = Declaration.FetchAll();
            //dataGridView1.DataSource = declarations;
        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2ControlBox1_Click(object sender, EventArgs e)
        {

        }

        private void guna2ControlBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanelPrincipale_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            flowLayoutPanelPrincipale.Controls.Clear();
            UserControlInspection user = new UserControlInspection();
            flowLayoutPanelPrincipale.Controls.Add(user);
        }

        private void userControlInspection1_Load(object sender, EventArgs e)
        {

        }
    }
}
