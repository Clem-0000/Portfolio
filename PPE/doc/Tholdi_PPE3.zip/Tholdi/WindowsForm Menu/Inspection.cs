﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForm_Menu
{
    class Inspection
    {
        private int _numInspection;
        private DateTime _dateInspection;
        private string _commentairePostInspection;
        private string _avis;
        private string _libelleMotif;
        private string _libelleEtat;
        private Container _container;
        private List<Decision> _decisions;


        public int NumInspection
        {
            get { return _numInspection; }
            set { _numInspection = value; }
        }
        public DateTime DateInspection
        {
            get { return _dateInspection; }
            set { _dateInspection = value; }
        }
        public string CommentairePostInspection
        {
            get { return _commentairePostInspection; }
            set { _commentairePostInspection = value; }
        }
        public string Avis
        {
            get { return _avis; }
            set { _avis = value; }
        }
        public string LibelleMotif
        {
            get { return _libelleMotif; }
            set { _libelleMotif = value; }
        }
        public Container Container
        {
            get { return _container; }
            set { _container = value; }
        }
      

        public Inspection(int numInspection, DateTime dateInspection, string commentairePostInspection, string avis, string libelleMotif, string libelleEtat)
        {
            this._numInspection = numInspection;
            this._dateInspection = dateInspection;
            this._commentairePostInspection = commentairePostInspection;
            this._avis = avis;
            this._libelleMotif = libelleMotif;
            this._libelleEtat = libelleEtat;
            this._decisions = new List<Decision>();
        }

        public void AjouterContainer(int numContainer, DateTime dateAchat, string typeContainer, DateTime dateDerniereInsp)
        {
            Container unContainer = new Container(numContainer, dateAchat, typeContainer, dateDerniereInsp);
            ////////manque un traitement
        }
        //public bool SupprimerContainer (Container unContainer)
        //{
        //    return _container.Remove(unContainer);
        //}
        public void AjouterDecision(DateTime dateEnvoie, DateTime dateRetour, string commentaireDecision)
        {
            //ajouter condition pour voir si une decision n'est pas vide
            Decision uneDecision = new Decision(dateEnvoie, dateRetour, commentaireDecision);
            _decisions.Add(uneDecision);
        }


     

        //public override bool Equals(object uneDecision)



        public override int GetHashCode()
        {
            return this.ToString().GetHashCode();
        }


        public override string ToString()
        {
            return "numéro d'inspection :" + NumInspection + "Date inspection : " + DateInspection + "Commentaire post inspection : " + CommentairePostInspection +
            "Avis d'inspection : " + Avis + "Nom du motif : " + LibelleMotif + "Container concerné : " + Container;
        }

    }
}

