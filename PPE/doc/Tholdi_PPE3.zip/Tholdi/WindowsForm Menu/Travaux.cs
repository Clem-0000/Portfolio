﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForm_Menu
{
    class Travaux
    {
        private char _codeTravaux;
        private string _libelleTravaux;
        private int _dureeImmobilisation;

        public char CodeTravaux
        {
            get { return _codeTravaux; }
            set { _codeTravaux = value; }
        }
        public string LibelleTravaux
        {
            get { return _libelleTravaux; }
            set { _libelleTravaux = value; }
        }
        public int DureeImmobilisation
        {
            get { return _dureeImmobilisation; }
            set { _dureeImmobilisation = value; }
        }

        public Travaux(char codeTravaux, string libelleTravaux, int dureeImmobilisation)
        {
            this._codeTravaux = codeTravaux;
            this._libelleTravaux = libelleTravaux;
            this._dureeImmobilisation = dureeImmobilisation;
        }
        // public Decision obtenirUneDecision
        //public Decision supprimerUneDecision

        public override int GetHashCode()
        {
            return _codeTravaux;
        }
        public override string ToString()
        {
            return "Salut";
        }
    }
}
