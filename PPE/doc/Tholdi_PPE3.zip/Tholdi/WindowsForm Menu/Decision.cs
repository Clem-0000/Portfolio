﻿  using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForm_Menu
{
    class Decision
    {

        private DateTime _dateEnvoie;
        private DateTime _dateRetour;
        private string _commentaireDecision;
        private Travaux _unTravail;

        public DateTime DateEnvoie
        {
            get { return _dateEnvoie; }
            set { _dateEnvoie = value; }
        }
        public DateTime DateRetour
        {
            get { return _dateRetour; }
            set { _dateRetour = value; }
        }
        public string CommentaireDecision
        {
            get { return _commentaireDecision; }
            set { _commentaireDecision = value; }
        }
        public Travaux UnTravail
        {
            get { return _unTravail; }
            set { _unTravail = value; }
        }

        public Decision(DateTime dateEnvoie, DateTime dateRetour, string commentaireDecision)
        {
            this._dateEnvoie = dateEnvoie;
            this._dateRetour = dateRetour;
            this._commentaireDecision = commentaireDecision;
        }




        //public void AjouterSessionDeFormation(int numero, byte nombreMaxParticipant, DateTime dateSession, Decimal coutPrevu)
        //{
        //    SessionFormation sf = new SessionFormation(numero, nombreMaxParticipant, dateSession, coutPrevu);
        //    _lesSessionsDeFormation.Add(sf);
        //}

        //public bool SupprimerSessionDeFormation(int numero)
        //{
        //    return _lesSessionsDeFormation.Remove(ObtenirSessionFormation(numero));
        //}


        //public SessionFormation ObtenirSessionFormation(int numeroSessionFormation)
        //{
        //    SessionFormation sessionFormation = null;
        //    foreach (SessionFormation sfCourante in _lesSessionsDeFormation)
        //    {
        //        if (sfCourante.Numero == numeroSessionFormation)
        //        {
        //            sessionFormation = sfCourante;
        //            break;
        //        }
        //    }
        //    return sessionFormation;
        //}


        //public override bool Equals(object actionDeFormation)
        //{
        //    bool memeActionDeFormation = false;
        //    ActionFormation af = actionDeFormation as ActionFormation;
        //    if (af != null)
        //    {
        //        if (af._codeAction == _codeAction)
        //        {
        //            memeActionDeFormation = true;
        //        }
        //    }
        //    return memeActionDeFormation;
        //}


        //public override int GetHashCode()
        //{
        //    return this.ToString().GetHashCode();
        //}


        //public override string ToString()
        //{
        //    return _intitule;
        //}
    }
}
