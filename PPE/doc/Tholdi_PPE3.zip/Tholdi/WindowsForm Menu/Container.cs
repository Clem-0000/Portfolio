﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsForm_Menu
{
    class Container
    {


        private static MySqlConnection _connexion = new MySqlConnection("Database=tholdi_ppe3;Data Source=localhost;User Id=root;Password=''");


        private static string _selectSql =
            "SELECT numContainer , dateAchat , typeContainer , dateDerniereInspi , traite  FROM container ";
        //#region 
        private int _numContainer;
        private DateTime _dateAchat;
        private string _typeContainer;
        private DateTime _dateDerniereInsp;
        List<Declaration> _lesDeclarations;
        List<Inspection> _lesInspections;


       
        public int NumContainer
        {
            get { return _numContainer; }
            set { _numContainer = value; }
        }
        public DateTime DateAchat
        {
            get { return _dateAchat; }
            set { _dateAchat = value; }
        }
        public string TypeContainer
        {
            get { return _typeContainer; }
            set { _typeContainer = value; }
        }
        public DateTime DateDerniereIns
        {
            get { return _dateDerniereInsp; }
            set { _dateDerniereInsp = value; }
        }

        
        public Container(int numContainer, DateTime dateAchat, string typeContainer, DateTime dateDerniereInsp)
        {
            this._numContainer = numContainer;
            this._dateAchat = dateAchat;
            this._typeContainer = typeContainer;
            this._dateDerniereInsp = dateDerniereInsp;
        }
        

        public Container()
        {

        }

        public static List<Container> FetchAll()
        {
            List<Container> resultat = new List<Container>();
            DataBaseAccess.Connexion.Open();
            MySqlCommand commandSql = DataBaseAccess.Connexion.CreateCommand();
            commandSql.CommandText = _selectSql;
            MySqlDataReader jeuEnregistrements = commandSql.ExecuteReader();

            while (jeuEnregistrements.Read())
            {

                Container container = new Container();

                string idContainer = jeuEnregistrements["numContainer"].ToString();
                container.NumContainer = Convert.ToInt16(idContainer);
                container.DateAchat = (DateTime)jeuEnregistrements["dateAchat"];
                container.TypeContainer = jeuEnregistrements["typeContainer"].ToString() ;
                container.DateDerniereIns = (DateTime)jeuEnregistrements["dateDerniereInsp"];
                resultat.Add(container);
            }
            DataBaseAccess.Connexion.Close();
            return resultat;
        }



    }
}