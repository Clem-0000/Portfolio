﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsForm_Menu
{
    class Declaration
    {

        private static MySqlConnection _connexion = new MySqlConnection("Database=tholdi_ppe3;Data Source=localhost;User Id=root;Password=''");

        private int codeDeclaration;
        private string commentaireDeclaration;
        private DateTime dateDeclaration;
        private bool urgence;
        private bool traite;
        private string codeDocker;
        private string libelleProbleme;
        private short id;


        #region Accesseurs_Mutateurs
        public int CodeDeclaration { get => codeDeclaration; /*set => codeDeclaration = value;*/}

        public string CommentaireDeclaration { get => commentaireDeclaration; set => commentaireDeclaration = value; }
        public DateTime DateDeclaration { get => dateDeclaration; set => dateDeclaration = value; }
        public bool Urgence { get => urgence; set => urgence = value; }
        public bool Traite { get => traite; set => traite = value; }
        public short Id
        {
            get { return id; }
        }
        public string CodeDocker { get => codeDocker; }
        public string LibelleProbleme { get => libelleProbleme; set => libelleProbleme = value; }



        #endregion

        #region Déclaration

        public Declaration()
        {
            id = -1;
        }


        #endregion

        #region Champs à porter classe - SQL

        private static string _selectSql =
            "SELECT codeDeclaration , commentaireDeclaration , dateDecision , urgence , traite , numContainer,  codeProbleme , libelleProbleme, codeDocker FROM declaration";

        private static string _selectByIdSql =
            "SELECT codeDeclaration , commentaireDeclaration , dateDecision  , urgence , traite , codeProbleme , libelleProbleme FROM declaration where codeDeclaration = ?id";

        private static string _updateSql =
            "UPDATE DECLARATION SET commentaireDeclaration = ?commentaireDeclaration , dateDecision  = ?dateDecision  , urgence = ?urgence , traite = ?traite , libelleProbleme = ?libelleProbleme WHERE codeDeclaration = ?id";

        private static string _insertSql =
            "INSERT INTO declaration (commentaireDeclaration ,dateDecision , urgence , traite ,codeProbleme , libelleProbleme) values (?commentaireDeclaration , ? dateDecision , ?urgence , ?traite , ?codeProbleme , ?libelleProbleme)";

        private static string _deleteSql =
            "DELETE FROM declaration WHERE codeDeclaration = ?id";
        private static string _getNumContainer =
            "Select numContainer from declaration";
        private static string _getLastInstertId =
            "Select codeDeclaration FROM declaration Where commentaireDeclaration = ?commentaireDeclaration AND dateDecision  = ?dateDecision  AND urgence = ?urgence AND  traite = ?traite AND libelleProbleme = ?libelleProbleme";
       
        #endregion

        #region Methodes

        public static List<Declaration> FetchAll()
        {
            List<Declaration> resultat = new List<Declaration>();
            DataBaseAccess.Connexion.Open();
            
            MySqlCommand commandSql = DataBaseAccess.Connexion.CreateCommand();
            commandSql.CommandText = _selectSql;
            MySqlDataReader jeuEnregistrements = commandSql.ExecuteReader();

            while (jeuEnregistrements.Read())
            {

                Declaration declaration = new Declaration();
                string idDeclaration = jeuEnregistrements["codeDeclaration"].ToString();
                declaration.codeDeclaration = Convert.ToInt16(idDeclaration);
                declaration.commentaireDeclaration = jeuEnregistrements["commentaireDeclaration"].ToString();
                declaration.dateDeclaration = (DateTime)jeuEnregistrements["dateDecision"];
                declaration.urgence = (bool)jeuEnregistrements["urgence"];
                declaration.traite = (bool)jeuEnregistrements["traite"];
                declaration.codeDocker = (string)jeuEnregistrements["codeProbleme"];
                declaration.libelleProbleme = (string)jeuEnregistrements["libelleProbleme"];
                resultat.Add(declaration);
            }
            DataBaseAccess.Connexion.Close();
            return resultat;
        }

        public static bool Insert(string commentaireDeclaration, DateTime dateDecision, bool urgence, bool traite, string libelleProbleme)
        {
            DataBaseAccess.Connexion.Open();
            bool succes = false;

            MySqlCommand commandSql = DataBaseAccess.Connexion.CreateCommand();
            commandSql.CommandText = _insertSql;

            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?commentaireDeclaration", commentaireDeclaration));
            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?dateDecision", dateDecision));
            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?urgence", urgence));
            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?traite", traite));
            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?libelleProbleme", libelleProbleme));
            commandSql.Prepare();
            int req = commandSql.ExecuteNonQuery();

            MySqlCommand commandGetLastId = DataBaseAccess.Connexion.CreateCommand();
            commandGetLastId.CommandText = _getLastInstertId;
            commandGetLastId.Parameters.Add(DataBaseAccess.CodeParam("?commentaireDeclaration", commentaireDeclaration));
            commandGetLastId.Parameters.Add(DataBaseAccess.CodeParam("?dateDecision", dateDecision));
            commandGetLastId.Parameters.Add(DataBaseAccess.CodeParam("?urgence", urgence));
            commandGetLastId.Parameters.Add(DataBaseAccess.CodeParam("?traite", traite));
            commandGetLastId.Parameters.Add(DataBaseAccess.CodeParam("?libelleProbleme", libelleProbleme));
            commandGetLastId.Prepare();

            if(req != 0)
            {
                succes = true;
            }
            return succes;

        }

        public void Update()

        {
            DataBaseAccess.Connexion.Open();
            MySqlCommand commandSql = DataBaseAccess.Connexion.CreateCommand();
            commandSql.CommandText = _updateSql;
            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?commentaireDeclaration", commentaireDeclaration));
            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?dateDecision", dateDeclaration));
            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?urgence", urgence));
            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?traite", traite));
            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?libelleProbleme", libelleProbleme));
            commandSql.Prepare();
            commandSql.ExecuteNonQuery();
            DataBaseAccess.Connexion.Close();
        }

        public void Delete()
        {
            DataBaseAccess.Connexion.Open();
            MySqlCommand commandSql = DataBaseAccess.Connexion.CreateCommand();
            commandSql.CommandText = _deleteSql;
            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?id", id));
            commandSql.Prepare();
            commandSql.ExecuteNonQuery();
            id = -1;

        }

        public static Declaration Fetch(int idDecla)
        {
            Declaration d = null;
            DataBaseAccess.Connexion.Open();
            MySqlCommand commandSql = DataBaseAccess.Connexion.CreateCommand();
            commandSql.CommandText = _selectByIdSql;
            commandSql.Parameters.Add(DataBaseAccess.CodeParam("?codeDeclaration", idDecla));
            commandSql.Prepare();
            MySqlDataReader jeuEnregistrements = commandSql.ExecuteReader();
            bool existEnregistrement = jeuEnregistrements.Read();
            if (existEnregistrement)
            {
                d = new Declaration();
                d.codeDeclaration = Convert.ToInt16(jeuEnregistrements["codeDeclaration"].ToString());
                d.commentaireDeclaration = jeuEnregistrements["Nom"].ToString();
                d.dateDeclaration = (DateTime)jeuEnregistrements["dateDecision"];
                d.urgence = (bool)jeuEnregistrements["urgence"];
                d.traite = (bool)jeuEnregistrements["traite"];
                d.codeDocker = (string)jeuEnregistrements["codeDocker"];
                d.libelleProbleme = (string)jeuEnregistrements["libelleProbleme"];
            }
            DataBaseAccess.Connexion.Close();
            return d;

        }
        #endregion


    }
}





