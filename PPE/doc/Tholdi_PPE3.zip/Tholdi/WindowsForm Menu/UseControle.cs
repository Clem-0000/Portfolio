﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsForm_Menu
{
    public partial class UseControle : UserControl
    {
      
        public UseControle()
        {
            InitializeComponent();
        }
        private void UseControle_Load(object sender, EventArgs e)
        {
            

        }
        private void button1_Click(object sender, EventArgs e)
        {
            var connection_pp3 = DataBaseAccess.Connexion;
            //déclarations des variables
            DateTime dateDecision;
            string commentaireDeclaration, libelle;
            bool urgence, traite;
            string succes = null;
            int numContainer;

            //affectation des variables
            commentaireDeclaration = textCommentaireDeclaration.Text;
            urgence = radioButton1.Checked;
            traite = radioButton2.Checked;
            libelle = textLibelle.Text;
            numContainer = Convert.ToInt32(comboBox1.SelectedItem);
            dateDecision = Convert.ToDateTime(dateTimePicker1.Value);


            //Insert requete

            succes = "INSERT INTO declaration (commentaireDeclaration ,dateDecision , urgence , traite ,libelleProbleme , numContainer) values ('" + commentaireDeclaration + "' , '" + dateDecision + "' , " +
               "'" + urgence + "' , '" + traite + "' , '" + libelle + "' , '" + numContainer + "')";
            try
            {
                connection_pp3.SubmitChanges(succes);
                MySqlDataAdapter sda = new MySqlDataAdapter(succes, connection_pp3);
                UseControle d = new UseControle();
                this.Controls.Add(d);
                
                connection_pp3.Close();

                if (succes != null)
                {
                    MessageBox.Show("La déclaration a été ajoutée");
                }
                else
                {
                    MessageBox.Show("Une erreur est survenue");
                }
            }
            catch
            {
                MessageBox.Show("Une erreur est survenue");
            }
            finally
            {
                connection_pp3.Close();
            }
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

        