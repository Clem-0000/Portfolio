﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForm_Menu
{
    class Probleme
    {
        public string CodeProbleme { get; private set;}
        public string Libelle { get; private set; }

    }
}
