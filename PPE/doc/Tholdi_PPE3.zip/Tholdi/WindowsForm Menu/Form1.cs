﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace WindowsForm_Menu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {

        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {

            var connection_pp3 = DataBaseAccess.Connexion;

            //var sql = "SELECT count(login) FROM utilisateur where login= textBoxNomUtilisateur.Text and mdp=textBoxMotDePasse.Text";
            //var cmd = new MySqlCommand(sql, connection_pp3);

            string user_login = textBoxNomUtilisateur.Text;
            string user_mdp = textBoxMotDePasse.Text;
            try
            {
               string querry = "SELECT count(login) as nb FROM utilisateur where login = '"+textBoxNomUtilisateur.Text+ "' and mdp = '" + textBoxMotDePasse.Text + "'";
                MySqlDataAdapter sda = new MySqlDataAdapter(querry, connection_pp3);
                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                if (dtable.Rows[0]["nb"].ToString() != "0")
                {
                    user_login = textBoxNomUtilisateur.Text;
                    user_mdp = textBoxMotDePasse.Text;

                    FormMenu F = new FormMenu();
                    F.Show();
                    this.Hide();
                    connection_pp3.Close();
                }
                else
                {
                    MessageBox.Show("invalid login details", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxNomUtilisateur.Clear();
                    textBoxMotDePasse.Clear();

                    textBoxNomUtilisateur.Focus();
                }
            }
            catch
            {
                MessageBox.Show("Error");
            }
            finally
            {
                connection_pp3.Close();
            }

           /* using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                reader.Read();
                string login = reader["login"].ToString();
                string mdp = reader["mdp"].ToString();

                if (login == textBoxNomUtilisateur.Text && mdp == textBoxMotDePasse.Text)
                {
                    FormMenu F = new FormMenu();
                    F.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Mot de passe incorrect");
                }
            }*/
           
        }

        private void guna2ControlBox3_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
            if(textBoxMotDePasse.UseSystemPasswordChar)
            {
                textBoxMotDePasse.UseSystemPasswordChar = false;
            }
            else
            {
                textBoxMotDePasse.UseSystemPasswordChar = true;
            }
        }
    }
}
    
