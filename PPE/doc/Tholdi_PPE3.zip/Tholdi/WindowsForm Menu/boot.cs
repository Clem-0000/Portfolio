﻿namespace WindowsForm_Menu
{
    internal class boot
    {
    }
}