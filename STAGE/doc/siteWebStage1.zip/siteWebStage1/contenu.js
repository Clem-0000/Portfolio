let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
    showSlides(slideIndex += n);
}

function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    let slides = document.getElementsByClassName('slides');
    let dots = document.getElementsByClassName('dot');

    if (n > slides.length) { slideIndex = 1 }

    if (n < 1) { slideIndex = slides.length }

    // Cacher toutes les slides
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }

    // Retirer "active" de tous les points
    for (let i = 0; i < dots.length; i++) {
        dots[i].classList.remove('active');
    }

    // Afficher la slide demandée
    slides[slideIndex - 1].style.display = 'block';

    // Ajouter "active" sur le point cliqué
    dots[slideIndex - 1].classList.add('active');
}

//--------------------fleche remonte page-----------------------------

const btn = document.querySelector('.btnArrow');

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        btn.classList.add("active");
    } else {
        btn.classList.remove("active");
    }
})
btn.addEventListener('click', () => {

    window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth"
    })

})